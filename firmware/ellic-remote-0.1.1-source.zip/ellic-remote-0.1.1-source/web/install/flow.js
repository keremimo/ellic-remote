// SPDX-License-Identifier: MPL-2.0
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
// Portions Copyright (C) 2026 Charles Vestal
//
// The installer's decisions, without the page: what a connected FM-1 is running, what an install will do, how
// far it has got, and what a failure leaves behind. progressModel() follows fm1-base's installer.html.

import { ufwEntries } from "./fm1pkg.js";

export const IS_OTA = (id) => /^ota-/i.test(id.model);
const OPEN_RE = /^FM1_(OFFICIAL_OPEN|COMMUNITY_\d+)$/;

// the identities' prefixes (fm1-base tools/build.py: a development build is the prefix and "00", a release the
// prefix and XXYYZZ): Ellic Remote's, and Saadet's, which an FM-1 may run before
export const PREFIX = "FM-1_14", SAADET = "FM-1_9";

// "FM-1_14010200" -> "1.2", "FM-1_14010203" -> "1.2.3"
export function releaseVersion(product, prefix = PREFIX) {
  if (!product.startsWith(prefix)) return null;
  const m = /^(\d\d)(\d\d)(\d\d)$/.exec(product.slice(prefix.length));
  if (!m) return null;
  const [x, y, z] = m.slice(1).map(Number);
  return z ? `${x}.${y}.${z}` : `${x}.${y}`;
}

// a connected FM-1, from its identity: { kind, version }
//   loader   in update mode: an install waits to be finished
//   this     the version this page installs
//   remote   another Ellic Remote release; dev: a development build (FM-1_1400)
//   saadet   Saadet (version: its release, or null for a development build)
//   stock    M-VAVE's own firmware (version: "V16"); open: M-VAVE's Open firmware (must go back to stock first)
//   other    another firmware for the FM-1; model: not an FM-1
export function describeDevice(id, product) {
  if (!id) return { kind: "none" };
  if (IS_OTA(id)) return { kind: "loader" };
  if (id.open || OPEN_RE.test(id.text)) return { kind: "open" };
  if (id.model !== "FM-1") return { kind: "model", text: id.text };
  if (id.text === product) return { kind: "this", version: releaseVersion(product) };
  if (id.text === PREFIX + "00") return { kind: "dev" };
  const v = releaseVersion(id.text);
  if (v) return { kind: "remote", version: v };
  if (id.text === SAADET + "00") return { kind: "saadet", version: null };
  const sv = releaseVersion(id.text, SAADET);
  if (sv) return { kind: "saadet", version: sv };
  if (/^FM-1_0\d\d$/.test(id.text) && id.text !== "FM-1_099") return { kind: "stock", version: "V" + parseInt(id.text.slice(5), 10) };
  return { kind: "other", text: id.text };
}

// what pressing Install does for a device: { firmware, resume, boot } or null (nothing to do)
export function planFor(kind, wantBoot) {
  if (kind === "loader") return { firmware: true, resume: true, boot: wantBoot };
  if (kind === "this") return wantBoot ? { firmware: false, resume: false, boot: true } : { firmware: true, resume: false, boot: false };
  if (kind === "open" || kind === "model" || kind === "none") return null;
  return { firmware: true, resume: false, boot: wantBoot };
}

// the bytes the device reads, for the bar. Step 1 (the running firmware): the UFW header, the loader's head twice,
// its body. Step 2 (the loader): the header, the chip-key check, the whole flash.bin (checked before anything is
// erased), then the app area again as it writes it. A resume has step 2 only. Without a readable flash.bin entry
// the whole image stands for it.
export function progressModel(image, resume = false) {
  let ent = {};
  try { ent = ufwEntries(image); } catch (_) { /* not a UFW image */ }
  const fl = ent[0], ldr = ent[100];
  const flen = fl && fl.len > 0x4000 && fl.len <= 0x100000 ? fl.len : image.length;
  const check = resume ? 0 : 0x400 + 0x400 + (ldr && ldr.len > 0x20 && ldr.len < image.length ? ldr.len - 0x20 : 0);
  const write = 0x400 + 0x20 + flen + Math.max(0, flen - 0x4000);
  const total = check + write;
  return {
    check, write, total,
    verify: (b) => (Math.min(b, check) / total) * 100,
    writing: (b) => Math.min(99, ((check + Math.min(b, write)) / total) * 100),
  };
}

// minutes and seconds left at the rate so far, or null while it is too early to say
export function remaining(done, total, ms) {
  if (done < total * 0.04 || ms < 3000) return null;
  return Math.max(0, Math.round(((total - done) / done) * ms / 1000));
}

// what a failure leaves: "safe" (nothing written), "paused" (in update mode: resume), "restart" (written; the FM-1
// did not come back as expected), "partial" (the firmware installed, m-bootloader not)
export function afterFailure(code, phase) {
  if (phase === "boot") return code === "noreturn" ? "restart" : "partial";
  if (phase === "done") return "restart";
  if (phase === "staged") return code === "noreturn" || code === "mismatch" ? "restart" : "paused";
  return "safe";
}
