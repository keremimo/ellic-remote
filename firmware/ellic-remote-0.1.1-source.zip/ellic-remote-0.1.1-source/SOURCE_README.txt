Ellic Remote 0.1.1 matching firmware source

Application commit: a3d36f4c4edf3a413c292bfc28df987c2b51732d
Package SHA-256: 3658fd80ac248d3f7e33943ac1485d39f32a431b0667bc087c04a2e483e670be

The application source is at this directory's root. Exact fm1-base and
felucca-bsp source copies are under dependencies/fm1-base/ and its bsp/.
SOURCE_INFO.json records the revisions and application file hashes.

Follow BUILDING.md to rebuild with ./build.sh --release 0.1.1.
The wrapper fetches the recorded revisions into build/deps/.
The JieLi compiler and SDK must be installed separately as described there;
the vendor SDK binaries and compiler are not included in this source ZIP.

MPL-covered source is supplied under MPL-2.0. Other files retain their own
licences/notices. Read LICENSE, LICENSING.md and the LICENSES directories.
