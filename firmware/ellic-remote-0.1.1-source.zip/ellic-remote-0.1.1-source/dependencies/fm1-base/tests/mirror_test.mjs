// SPDX-License-Identifier: MPL-2.0
// Copyright (C) 2026 Charles Vestal
// The mirror viewer's decoder (web/mirror/index.html, the part between its "decoder" markers) on the device's own SysEx
// stream, as device/mirror.c sent it in tests/mirror_test.c's session (--out DIR): the screen it rebuilds against the
// device's screen, and the panel's reports (a button and keys held, knobs turned, MASTER, the lights), a remote
// request's answer. (From Polly's.)
//   node tests/mirror_test.mjs DIR
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const dir = process.argv[2];
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const html = fs.readFileSync(path.join(root, "web/mirror/index.html"), "utf8");
const m = /\/\/ --- decoder: begin[^\n]*\n([\s\S]*?)\/\/ --- decoder: end/.exec(html);
if (!m) { console.log("FAIL no decoder markers in web/mirror/index.html"); process.exit(1); }
const { createMirror, mrRequest, mrRemote, mrUnpack7 } =
  new Function(`"use strict";\n${m[1]}\nreturn { createMirror, mrRequest, mrRemote, mrUnpack7 };`)();

let fails = 0;
const check = (ok, msg) => { if (!ok) { console.log("FAIL " + msg); fails++; } };

// the requests, as the device's ota_take reads them
for (const op of [0, 1, 2]) {
  const r = mrRequest(op), u = mrUnpack7(r.slice(1, -1));
  check(r[0] === 0xF0 && r[r.length - 1] === 0xF7 && u.join() === [0, 0x59, 0x50, 1, 0, 0, op, ~op & 0xFF].join(), `request ${op}: ${[...r]}`);
}

// the remote's requests (Control), as main_fm1.c takes them: seq, op, a, b, 0, the sum
{
  const r = mrRemote(300, 3, 4, -1), u = mrUnpack7(r.slice(1, -1)), body = [300 & 255, 3, 4, 255, 0];
  check(r[0] === 0xF0 && r[r.length - 1] === 0xF7 && u.join() === [0, 0x59, 0x54, 5, 0, 0, ...body,
        ~body.reduce((a, v) => a + v, 0) & 0xFF].join(), `remote: ${[...r]}`);
  let got = null;                                    // its answer, decoded
  const d = createMirror({ remote: (x) => { got = x; } }), ans = [7, 1, 1];
  d.feed(Uint8Array.from([0xF0, ...mrPack7l([0, 0x59, 0x54, 3, 0, 0, ...ans, ~9 & 0xFF]), 0xF7]));
  check(got && got.seq === 7 && got.op === 1 && got.ok, `remote answer: ${JSON.stringify(got)}`);
}
function mrPack7l(bytes) {
  const out = [];
  let acc = 0, nb = 0;
  for (const b of bytes) { acc |= b << nb; nb += 8; while (nb >= 7) { out.push(acc & 0x7F); acc >>= 7; nb -= 7; } }
  if (nb) out.push(acc & 0x7F);
  return out;
}

// the simulator's screen dump (as stored: high byte first) -> RGB565
function dump(name) {
  const b = fs.readFileSync(path.join(dir, name)), px = new Uint16Array(240 * 240);
  for (let i = 0; i < px.length; i++) px[i] = b[2 * i] << 8 | b[2 * i + 1];
  return px;
}
function rowsDiffering(a, b) {
  let n = 0;
  for (let r = 0; r < 240; r++)
    for (let i = 0; i < 240; i++) if (a[r * 240 + i] !== b[r * 240 + i]) { n++; break; }
  return n;
}

// fed in pieces of any size (Web MIDI gives whole messages; a pipe may not)
function feedAll(dec, bytes, seed) {
  let s = seed, i = 0;
  while (i < bytes.length) {
    s = (s * 1103515245 + 12345) >>> 0;
    const n = 1 + (s >>> 16) % 700;
    dec.feed(bytes.subarray(i, i + n));
    i += n;
  }
}

const states = [];
let hellos = 0, rects = 0;
const answers = [];
const dec = createMirror({ input: (s) => states.push(s), hello: (h) => { if (h.on && h.w === 240 && h.h === 240) hellos++; },
                          rect: () => rects++, remote: (r) => answers.push(r) });
const stream = fs.readFileSync(path.join(dir, "stream.syx"));
feedAll(dec, stream, 1);
const st = dec.stats;
check(st.bad === 0, `${st.bad} bad frames`);
check(st.gaps === 0, `${st.gaps} frames missing (seq)`);
check(hellos >= 1, "no hello");
const diff = rowsDiffering(dec.screen, dump("screen.bin"));
check(diff === 0, `the screen: ${diff} rows differ from the device's (screen.bin)`);
check(answers.length === 2 && answers.every((a, i) => a.seq === 7 + i && a.op === 1 && a.ok), `remote answers: ${JSON.stringify(answers)}`);

// the panel: SEL held with keys 5 and 9, K1 +3, PRESETS -2, K2 +4, MASTER 3000, PLAY lit
const B_SEL = 1, B_PLAY = 10, EN_PRESET = 2, EN_K1 = 3, EN_K2 = 4;
const sum = [0, 0, 0, 0, 0, 0, 0];
for (const s of states) s.enc.forEach((n, i) => { sum[i] += n; });
check(states.some((s) => s.buttons & (1 << B_SEL) && (s.keys & 0x220) === 0x220), "no report of SEL held with keys 5 and 9");
check(sum[EN_K1] === 3 && sum[EN_PRESET] === -2 && sum[EN_K2] === 4, `the turns: ${sum} (K1 3, PRESETS -2, K2 4)`);
check(sum[0] === 0 && sum[1] === 0 && sum[5] === 0 && sum[6] === 0, `turns not made: ${sum}`);
check(states.length && states[states.length - 1].master === 3000, `MASTER ${states.length && states[states.length - 1].master}`);
check(states.some((s) => s.litButtons & (1 << B_PLAY) && !s.playRed), "PLAY never lit (green)");
check(states.length && !states[states.length - 1].buttons && !states[states.length - 1].keys, "a button or key left held");

// fed in other pieces: the same screen
const dec2 = createMirror();
feedAll(dec2, stream, 7);
check(dec2.stats.bad === 0 && dec2.stats.gaps === 0 && rowsDiffering(dec2.screen, dump("screen.bin")) === 0,
      `fed again in other pieces: ${dec2.stats.bad} bad, ${dec2.stats.gaps} missing`);

console.log(`${fails ? "FAILED" : "ok"}: ${stream.length} bytes, ${st.frames} frames (${st.rects} rects, ${st.fills} fills, ` +
            `${st.inputs} input reports), turns ${sum.join(" ")}`);
process.exit(fails ? 1 : 0);
