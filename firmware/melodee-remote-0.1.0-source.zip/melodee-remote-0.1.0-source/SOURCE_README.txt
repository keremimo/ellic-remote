Melodee Remote 0.1.0 matching firmware source

Application commit: c582228734d513a85508bf5a826ca9dd52fcfd5e
Package SHA-256: a4f6aff3a3c77a5d674de8a63cc628ef9b7fc00f2611b4a80ddf3db26806c695

The application source is at this directory's root. Exact fm1-base and
felucca-bsp source copies are under dependencies/fm1-base/ and its bsp/.
SOURCE_INFO.json records the revisions and application file hashes.

Follow BUILDING.md to rebuild with ./build.sh --release 0.1.0.
The wrapper fetches the recorded revisions into build/deps/.
The JieLi compiler and SDK must be installed separately as described there;
the vendor SDK binaries and compiler are not included in this source ZIP.

MPL-covered source is supplied under MPL-2.0. Other files retain their own
licences/notices. Read LICENSE, LICENSING.md and the LICENSES directories.
