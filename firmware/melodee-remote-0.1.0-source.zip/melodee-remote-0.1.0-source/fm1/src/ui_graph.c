/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio)
 * Portions Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Melodee UI: the panel (Y_GRAPH .. Y_GRAPH + H_GRAPH) between the cards and the footer: a SURF area
 * (rounded, on BG) holding the page graphs (ADSR, LFO, steps, piano roll, drum grid, scale,
 * MOD, lists: presets, user presets, patterns, project slots, song), the HOME oscilloscope, the
 * instrument diagrams; the MIXER page draws four SURF columns instead. Each graph is redrawn only when
 * graph_signature() changes. The look:
 * curves THEME (2 px), guides and empty marks RAISE, captions MID / DIM, the active thing ACCENT,
 * bars rounded; a list's selected row is a THEME bar with INK text. */
#define PANEL_X0 10                                  /* the graphs' inner area: x 10..230 */
#define PANEL_W 220
#define GOY 11                                       /* graphs drawn on a 100 px scale sit at y 11..111 */
static int32_t graph_y = Y_GRAPH, graph_h = H_GRAPH, graph_oy = GOY;   /* (graph_oy: the 100 px scale's top) */

/* Matches voice.c: attack is linear, decay and release are exponential
 * (env += (target - env) * k each tick, ~99 % after the set time). Time
 * axis is the parameter value (the times themselves are exponential). */
/* an ADSR of four values 0..127 between rows top and bot (Stage: the amp envelope while one of its knobs turns) */
static void graph_adsr_v(int32_t va, int32_t vd, int32_t vs, int32_t vr, int32_t top, int32_t bot, uint16_t c)
{
    int32_t a = 4 + va * 50 / 127, d = 6 + vd * 50 / 127, r = 6 + vr * 60 / 127, sus = vs * 1000 / 127;   /* 0..1000 */
    int32_t x0 = 12, x1 = x0 + a, x3 = 226 - r, i, px, py;
    int32_t e = 32768;                                                  /* exp(-4.6 u), Q15 */
#define EGY(lvl) (bot - (lvl) * (bot - top) / 1000)
    cv_rect(PANEL_X0, bot + 2, PANEL_W, 1, T_RAISE);
    cv_line_t(x0, bot, x1, top, c, 2);                                  /* attack: linear */
    px = x1;
    py = top;
    for (i = 1; i <= d; i++) {                                          /* decay: exponential to SUS */
        int32_t lvl;
        e = (e * (32768 - 150733 / d)) >> 15;           /* k^d = exp(-4.6) */
        lvl = sus + ((1000 - sus) * e >> 15);
        cv_line_t(px, py, x1 + i, EGY(lvl), c, 2);
        px = x1 + i;
        py = EGY(lvl);
    }
    cv_line_t(px, py, x3, EGY(sus), c, 2);                               /* sustain */
    px = x3;
    py = EGY(sus);
    e = 32768;
    for (i = 1; i <= r; i++) {                                          /* release: exponential to 0 */
        e = (e * (32768 - 150733 / r)) >> 15;
        cv_line_t(px, py, x3 + i, EGY(sus * e >> 15), c, 2);
        px = x3 + i;
        py = EGY(sus * e >> 15);
    }
#undef EGY
}


static void graph_lfo(const track_t *t, uint16_t c)
{
    int32_t x, uni = t->p[P_LPOL] != 0, z = uni ? 88 : 50, py = z;   /* the zero line: POL UNI (LFO 2) draws 0..+1 over it */
    uint32_t ph = (uint32_t)t->p[P_LPHASE] << 25;
    cv_rect(PANEL_X0, z, PANEL_W, 1, T_RAISE);
    for (x = 0; x < PANEL_W; x++) {                  /* two cycles (lfo_wave only reads the track) */
        int32_t w = lfo_wave((track_t *)t, ph + (uint32_t)x * (0xFFFFFFFFu / (PANEL_W / 2u))), y;
        if (t->p[P_LWAVE] == 4)
            w = (int32_t)((x / 20 * 2654435761u) >> 16) - 32768;
        y = uni ? z - (w + 32768) * 38 / 32768 : 50 - w * 38 / 32768;
        if (x)
            cv_line_t(PANEL_X0 + x - 1, py, PANEL_X0 + x, y, c, 2);
        py = y;
    }
}

/* step bar x of step i of a 16-step row: 4 groups, as the footer (9 px bars, 13 px apart, 4 px between groups) */
static int32_t bar_x(uint32_t i) { return 13 + (int32_t)(i % 16u) * 13 + (int32_t)(i % 16u / 4u) * 4; }

/* PATTERN page: the 64 steps as 4 rows of 16 bars (an accent: the accent colour, a tie: a lower bar,
 * empty: a stub), the cursor and the playhead under them */
static void graph_steps(const track_t *t, uint16_t c)
{
    uint32_t i, len = (uint32_t)t->p[P_SLEN];
    for (i = 0; i < NSTEP; i++) {
        int32_t x = bar_x(i), y = 4 + (int32_t)(i / 16u) * 24;
        const step_t *st = &seq_steps(t)[i];
        if (i >= len)
            continue;
        if (step_on(st))
            cv_rrect(x, y, 9, 14, 2, (st->flags & SF_ACCENT) ? T_ACCENT : c, T_SURF);
        else if (st->time == ST_TIE)
            cv_rrect(x, y + 8, 9, 6, 1, T_MID, T_SURF);
        else
            cv_rrect(x, y + 11, 9, 3, 1, T_RAISE, T_SURF);
        if (i == ui.cursor)
            cv_rect(x, y + 16, 9, 2, T_ACCENT);
        else if (song.playing && i == t->seq_idx)
            cv_rect(x, y + 16, 9, 2, T_TEXT);
    }
}

/* STEP page (a melodic track): a piano roll of the cursor's 16-step page. PR_ROWS semitone rows of PR_RH px,
 * the highest on top; on the left a keyboard strip (a C key named on it, 9 px) (white keys RAISE, black keys a
 * shorter DIM; a key held on the track: its row ACCENT). Rows out of the track's scale (SCL ROOT / SCALE; CHR: the
 * black keys) are darker (QUIET), a C row closes with a RAISE line; step lines GRID, every 4th RAISE. A note is a bar in
 * its column (an accent: TEXT, the row's full height; the cursor step's notes: ACCENT), chords stacked, lane hits as
 * their notes; a TIE carries the bars of the note before through its column; a REST is empty; a slide is a TEXT
 * diagonal from the end of its bar into the next note. Notes outside the view: a 1 px mark on the edge. The cursor:
 * a TEXT column frame; the playhead: a 1 px ACCENT line. The view (proll.lo, the bottom row) fits the notes of the
 * page, else centres on the cursor's note, and follows in steps (a third of the way per frame); graph_signature()
 * holds it, so a page that does not change is not drawn again. */
#define PR_TOP Y_GRAPH                              /* the panel's top on the screen (ui_pages.c: NOTES, under the strip) */
#define PR_H 154                                    /* .. its rows (84 .. 237) */
#define PR_ROWS 13                                  /* semitones shown (an octave and its top note) */
#define PR_RH 11                                    /* px per row */
#define PR_Y0 4                                     /* the top row (panel y) */
#define PR_X0 32                                    /* the first step column */
#define PR_CW 12                                    /* px per step */
#define PR_KX 6                                     /* the keyboard strip, 22 px (black keys 13; a C key named on it, the
                                                     * label face) */
static struct {
    uint8_t lo, trk, init, moving;                    /* lo: the note of the bottom row; moving: on its way */
    uint32_t frame;
    int32_t play;                                     /* the playhead's column drawn (notes_play_x) */
} proll;
static const uint8_t KEY_BLACK[12] = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0};

static uint32_t pr_src(const track_t *t, uint32_t si, uint32_t len)   /* the step whose notes sound at si (NSTEP: none) */
{
    uint32_t k;
    for (k = 0; k < len && seq_steps(t)[si].time == ST_TIE; k++)
        si = (si + len - 1u) % len;
    return step_on(&seq_steps(t)[si]) ? si : NSTEP;
}
/* the rows lit by keys held on the selected track (bit r: row r from the top) */
static uint32_t pr_held(void)
{
    uint32_t k, i, m = 0;
    for (k = 0; k < 27u; k++)
        if (kb_chn[k] && kb_trk[k] == song.sel)
            for (i = 0; i < kb_chn[k]; i++) {
                int32_t r = (int32_t)proll.lo + PR_ROWS - 1 - kb_chord[k][i];
                if (r >= 0 && r < PR_ROWS)
                    m |= 1u << r;
            }
    return m;
}
static int32_t pr_row_y(int32_t n) { return PR_Y0 + ((int32_t)proll.lo + PR_ROWS - 1 - n) * PR_RH; }
/* NOTES draws original sample times on a timeline. Swing changes the grid
 * spacing; finishing a take with QNT updates its stored/displayed onset. */
static void notes_window(const track_t *t, uint32_t period, uint32_t *a, uint32_t *b)
{
    uint32_t base = notes_base(), end = base + notes_span();
    if (end > (uint32_t)t->p[P_SLEN]) end = (uint32_t)t->p[P_SLEN];
    *a = recording_prefix(t, period, base);
    *b = recording_prefix(t, period, end);
}
static int32_t notes_x(uint32_t at, uint32_t a, uint32_t b)
{
    /* Callers clip to the visible interval before converting to pixels. */
    return PR_X0 + (int32_t)((uint64_t)(at - a) * (16 * PR_CW) / (b - a));
}
/* the playhead's column, -1: stopped or out of the view. The step and the samples into it read as one pair (the audio
 * may step on between the two reads: a step back for a frame) */
static int32_t notes_play_x(const track_t *t)
{
    const volatile track_t *v = t;
    uint32_t period = seq_div_samples((uint32_t)t->p[P_SDIV]), a, b, idx = 0, pos = 0, k, at;
    if (!song.playing)
        return -1;
    for (k = 0; k < 4u; k++) {
        idx = v->seq_idx;
        pos = v->seq_pos;
        if (idx == v->seq_idx)
            break;
    }
    if (pos >= 0x7FFFFFFFu)
        return -1;
    notes_window(t, period, &a, &b);
    at = recording_prefix(t, period, idx) + pos;
    return at >= a && at < b ? notes_x(at, a, b) : -1;
}
static void notes_follow(const track_t *t)
{
    uint32_t period = seq_div_samples((uint32_t)t->p[P_SDIV]), a, b, chosen = notes_selected(t);
    notes_window(t, period, &a, &b);
    int32_t lo = 127, hi = -1;
    for (uint32_t i = recording_head[recording_owner(t)]; i < RECORD_MAX; i = recording_next[i]) {
        if (!recording_active(t, i)) continue;
        uint32_t at = recording_raw_on(t, &recording[i], period);
        if (at < a || at >= b) continue;
        int32_t note = recorded_note(&recording[i]);
        if (note < lo) lo = note;
        if (note > hi) hi = note;
    }
    for (uint32_t si = 0; si < step_pattern_len(t); si++) {
        uint32_t source = pr_src(t, si, step_pattern_len(t));
        if (source == NSTEP || (seq_steps(t)[source].flags & SF_RECORDED)) continue;
        uint32_t at = recording_prefix(t, period, si);
        if (at < a || at >= b) continue;
        for (uint32_t j = 0; j < seq_steps(t)[source].n; j++) {
            int32_t note = seq_steps(t)[source].note[j];
            if (note < lo) lo = note;
            if (note > hi) hi = note;
        }
    }
    int32_t center = hi < 0 ? last_note : (lo + hi + 1) / 2;
    if (hi - lo >= PR_ROWS) {
        uint32_t at = notes_manual_start(t);
        if (chosen < RECORD_MAX) center = recorded_note(&recording[chosen]);
        else if (at < NSTEP && t->step[at].n) center = t->step[at].note[notes_manual_slot(&t->step[at])];
    }
    int32_t target = clamp(center - PR_ROWS / 2, 0, 128 - PR_ROWS);
    if (proll.frame == ui.frame && proll.init && !ui.force) return;
    int snap = ui.force || !proll.init || proll.trk != song.sel || ui.frame != proll.frame + 1u;
    int32_t d = target - proll.lo;
    proll.lo = (uint8_t)(snap ? target : proll.lo + (d / 3 ? d / 3 : d > 0 ? 1 : d < 0 ? -1 : 0));
    proll.moving = proll.lo != target; proll.trk = song.sel; proll.frame = ui.frame; proll.init = 1;
}
#define PR_OCT_C(n) T_KNOB((uint32_t)(n) / 12u)        /* a note in the roll: its octave's colour (as ARP's blocks) */
static void notes_bar(const track_t *t, uint32_t i, uint32_t period, uint32_t a, uint32_t b, uint16_t c, int selected)
{
    recorded_note_t snapshot = recording_snapshot(i);
    const recorded_note_t *r = &snapshot;
    if (c == T_THEME)
        c = PR_OCT_C(recorded_note(r));
    uint32_t loop = recording_loop(t, period), at = recording_raw_on(t, r, period);
    uint64_t gate = (uint64_t)r->duration * (1u << (recorded_exponent(r))) * period / RECORD_UNIT;
    if (!gate) gate = 1;
    if (gate > loop) gate = loop;
    int32_t y = pr_row_y(recorded_note(r)), bottom = PR_Y0 + PR_ROWS * PR_RH;
    for (int32_t wrap = -1; wrap <= 0; wrap++) {
        int64_t start = (int64_t)at + (int64_t)wrap * loop, end = start + gate;
        if (end <= a || start >= b) continue;
        int32_t x = notes_x(start < a ? a : start, a, b), xe = notes_x(end > b ? b : end, a, b);
        if (xe < x + 2) xe = x + 2;
        if (xe > PR_X0 + 16 * PR_CW) xe = PR_X0 + 16 * PR_CW;
        if (y < PR_Y0 || y >= bottom) {
            cv_rect(x, y < PR_Y0 ? PR_Y0 : bottom - 1, xe - x, 1, c);
        } else {
            cv_rect(x, y + 1, xe - x, PR_RH - 2, c);
            if (selected) cv_frame(x, y, xe - x, PR_RH, T_TEXT);
            /* An onset tick keeps two close hits visible when tails overlap. */
            if (start >= a) cv_rect(x, y, 1, PR_RH, selected ? T_TEXT : T_MID);
        }
    }
}
static void graph_recorded_notes(const track_t *t, uint16_t c)
{
    uint32_t period = seq_div_samples((uint32_t)t->p[P_SDIV]), a, b, chosen = notes_selected(t);
    notes_window(t, period, &a, &b);
    notes_follow(t);
    uint32_t held = pr_held();
    int32_t bottom = PR_Y0 + PR_ROWS * PR_RH;
    for (int32_t row = 0; row < PR_ROWS; row++) {
        int32_t note = (int32_t)proll.lo + PR_ROWS - 1 - row, y = PR_Y0 + row * PR_RH;
        if (!(micro_active(t) ? ((note - 60) & 1) == 0 : scale_mask(t) == 0xFFFu ? !KEY_BLACK[note % 12] : (scale_mask(t) >> ((note - t->p[P_ROOT] + 120) % 12)) & 1u)) cv_rect(PR_X0, y, 16 * PR_CW + 1, PR_RH, T_QUIET);   /* (out of the scale: darker) */
        cv_rect(PR_KX, y, !micro_active(t) && KEY_BLACK[note % 12] ? 13 : 22, PR_RH - 1, !micro_active(t) && KEY_BLACK[note % 12] ? T_DIM : T_RAISE);
        if ((held >> row) & 1u) cv_rect(PR_KX, y, 22, PR_RH - 1, T_ACCENT);
    }
    for (int32_t row = 0; row < PR_ROWS; row++) {      /* the C keys named (the label face, on their row's middle) */
        int32_t note = (int32_t)proll.lo + PR_ROWS - 1 - row, y = PR_Y0 + row * PR_RH;
        if (micro_active(t) ? ((note - 60) % (int32_t)scale_note_period(t) == 0) : note % 12 == 0) {
            char name[8];
            if (micro_active(t)) str_cpy(name, "D1", sizeof name); else note_name(name, (uint32_t)note);
            uint16_t lf = (held >> row) & 1u ? T_ACCENT : T_RAISE;   /* (held: the accent, as the key) */
            cv_rrect(3, ty_y(y + PR_RH / 2, TY_LB) + TY_LB->asc - TY_LB->cap - 3, text_w(TY_LB, name) + 8, TY_LB->cap + 6, 4,
                     lf, T_PANEL);
            cv_text_on(7, ty_y(y + PR_RH / 2, TY_LB), TY_LB, name, lf == T_ACCENT ? T_INK : T_TEXT, lf);
        }
    }
    uint32_t base = notes_base(), end = base + notes_span();
    if (end > (uint32_t)t->p[P_SLEN]) end = (uint32_t)t->p[P_SLEN];
    for (uint32_t step = base; step <= end; step++) {
        int32_t x;
        if (notes_span() > 16u && step % 4u)          /* (a bar or more shown: the beats' lines alone) */
            continue;
        x = notes_x(recording_prefix(t, period, step), a, b);
        cv_rect(x, PR_Y0, 1, bottom - PR_Y0, step % 4u ? T_GRID : step % 16u ? T_RAISE : T_MID);
    }
    if (proll.play >= 0) cv_rect(proll.play, PR_Y0, 1, bottom - PR_Y0, T_ACCENT);   /* (set by the caller: notes_play_x) */
    /* Manual notes use the same time axis and selection language. Ties
     * appear as a continuous note, including a tail wrapping into this view. */
    uint32_t selected_start = notes_manual_start(t);
    for (uint32_t si = base; si < end; si++) {
        uint32_t source = pr_src(t, si, step_pattern_len(t));
        if (source == NSTEP || (seq_steps(t)[source].flags & SF_RECORDED)) continue;
        const step_t *st = &seq_steps(t)[source];
        int32_t x = notes_x(recording_prefix(t, period, si), a, b);
        int32_t xe = notes_x(recording_prefix(t, period, si + 1u), a, b);
        for (uint32_t j = 0; j < st->n; j++) {
            int32_t y = pr_row_y(st->note[j]);
            int selected = (bulk.on&&bulk_has(source)) || (chosen >= RECORD_MAX && source == selected_start && (j == notes_manual_slot(st) || (st->n > 1u && ui.hot_t && (ui.hot_col == 2u || ui.hot_col == 3u))));
            /* (a note tied on: no gap at its column's end, one bar) */
            int32_t lead = source == si ? 2 : 0, cont = si + 1u < end && pr_src(t, si + 1u, step_pattern_len(t)) == source;
            uint16_t nc = c == T_THEME ? PR_OCT_C(st->note[j]) : c;
            if (y < PR_Y0 || y >= bottom) { cv_rect(x + 1, y < PR_Y0 ? PR_Y0 : bottom - 1, xe - x - 1, 1, nc); continue; }
            cv_rect(x + lead, y + 1, xe - x - lead - (cont ? 0 : 1), PR_RH - 2, selected ? T_ACCENT : nc);
            if (selected) cv_frame(x + (source == si ? 1 : 0), y, xe - x - (source == si ? 2 : 0), PR_RH, T_TEXT);
            uint32_t next = (si + 1u) % step_pattern_len(t);
            const step_t *ns = &seq_steps(t)[next];
            if (!j && (st->flags & SF_SLIDE) && si + 1u < end && ns->time == ST_NOTE && ns->n) {
                int32_t ny = clamp(pr_row_y(ns->note[0]), PR_Y0, bottom - PR_RH);
                cv_line(xe - 2, y + 2, xe + 2, ny + 2, T_TEXT);
            }
        }
    }
    for (uint32_t i = recording_head[recording_owner(t)]; i < RECORD_MAX; i = recording_next[i])
        if (i != chosen && recording_active(t, i)) notes_bar(t, i, period, a, b, bulk.on&&bulk_note_has(i)?T_ACCENT:c, bulk.on&&bulk_note_has(i));
    if (chosen < RECORD_MAX) notes_bar(t, chosen, period, a, b, T_ACCENT, 1);
    if (ui.cursor >= base && ui.cursor < end) {         /* the cursor's column, last: its right side is the next step's
                                                         * line, its left a tied note's bar (both drawn over it before) */
        int32_t x = notes_x(recording_prefix(t, period, ui.cursor), a, b), xe = notes_x(recording_prefix(t, period, ui.cursor + 1u), a, b);
        cv_frame(x, PR_Y0 - 2, xe - x + 1, bottom - PR_Y0 + 4, T_TEXT);
    }
}

/* SEQ > STEP on a DRUM track: the grid, 8 lanes x the 16 steps of the page shown. Lanes by their two-letter
 * names (BD SD CP CH OH TM RS CB; CG CL CY on the other kits). A hit is a rounded square (accented: the
 * accent), an empty step a dot (brighter on the beats and on the selected lane); the selected lane is
 * underlaid RAISE, the cursor framed in TEXT; a TEXT bar over the step playing */
static void graph_grid(const track_t *t, uint16_t c)
{
    uint32_t l, i, len = (uint32_t)t->p[P_SLEN], base = ui.bank * 16u, sound = ui.drum_sound % drum_sound_count(t);
    int32_t y0 = 6;
    for (l = 0; l < NLANE; l++) {
        int32_t y = y0 + 4 + (int32_t)l * 14;
        int sel = l == ui.lane;
        int pick = 0;
        uint16_t row = sel ? T_RAISE : T_SURF;
        if (sel)
            cv_rrect(6, y, 226, 14, 3, T_RAISE, T_SURF);
        cv_text_on(10, ty_y(y + 7, TY_LB), TY_LB, pick ? drum_sound_abbr(t, sound) : drum_lane_abbr(t, l), sel ? T_ACCENT : T_MID, row);
        for (i = 0; i < 16u && base + i < len; i++) {
            const step_t *st = &seq_steps(t)[base + i];
            uint32_t b = 1u << l;
            int32_t x = 44 + (int32_t)i * 12;
            if (step_lanes(st) & b) {
                uint16_t col = (step_accents(st) & b) ? T_ACCENT : c;
                cv_rrect(x, y + 2, 10, 10, 2, col, row);
                if (pick && step_sound_note(t, st, sound) < 0)
                    cv_rrect(x + 2, y + 4, 6, 6, 1, row, col);
            } else
                cv_rect(x + 4, y + 6, 2, 2, i % 4u == 0u || sel ? T_MID : T_DIM);
            if (sel && base + i == ui.cursor)          /* the cursor: a 1 px frame */
                cv_frame(x - 1, y + 1, 12, 12, T_TEXT);
        }
    }
    if (song.playing && t->seq_idx < len && t->seq_idx / 16u == ui.bank)
        cv_rect(44 + (int32_t)(t->seq_idx % 16u) * 12, y0 - 1, 10, 3, T_TEXT);
}
/* SCL: the 12 keys as rounded bars (black keys high, white keys low): in the scale THEME, the root the
 * accent, out of the scale RAISE */
static void graph_scale(const track_t *t, uint16_t c)
{
    static const uint8_t BLACK[12] = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0};
    const micro_scale_t *s = micro_scale(t);
    if (s) {
        char label[24];
        fmt_int(label, s->count);
        str_cpy(label + str_len(label), " DEGREES / PERIOD", 20);
        cv_text_c(120, ty_y(14, TY_LB), TY_LB, label, T_MID, T_SURF);
        cv_rect(12, 91, 216, 1, T_RAISE);
        for (uint32_t d = 0; d <= s->count; d++) {
            int32_t x = 12 + s->pitch[d] * 216 / s->pitch[s->count];
            cv_rect(x, d ? 48 : 36, 2, d ? 42 : 54, d ? c : T_ACCENT);
        }
        return;
    }
    uint32_t i, mask = scale_mask(t);
    for (i = 0; i < 12u; i++) {
        uint32_t deg = (i + 12u - (uint32_t)t->p[P_ROOT]) % 12u;
        int32_t x = 13 + (int32_t)i * 18;
        uint16_t col = (mask >> deg) & 1u ? (deg == 0u ? T_ACCENT : c) : T_RAISE;
        cv_rrect(x + 3, BLACK[i] ? 6 : 38, 10, 52, 3, col, T_SURF);
    }
}
/* CHORD (SCL 2): the chord's name ("Cm7": the last one the track played; before any, the one on its ROOT from
 * C4) over the keys from the C below its lowest note (two octaves, three for a wide one): its notes THEME, its
 * root's ACCENT, the others RAISE. OFF or a kit: what to do instead */
static void panel_note(const char *a, const char *b, const char *c);
static void graph_chord(const track_t *t, uint16_t c)
{
    static const uint8_t BLACK[12] = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0};
    uint8_t nn[CHORD_MAX];
    uint32_t n, i, j, k = trk_index(t), lo, cnt, w;
    int32_t r;
    uint16_t mask;
    char b[12];
    const char *cap = "LAST";
    if (!t->p[P_CHRD]) {
        panel_note("CHORD KEYS OFF", "[K1] DIA3: IN-KEY CHORDS", 0);   /* (the title says what they are) */
        return;
    }
    if (chord_kit(t)) {
        panel_note("NO CHORDS ON KITS", 0, 0);
        return;
    }
    if ((t->p[P_CHRD] == CH_AUTO || t->p[P_CHRD] == CH_MELODY) && micro_scale(t)) {
        panel_note("AUTO: WESTERN SCALES", "CHOOSE DIA3 OR DIA7", 0);
        return;
    }
    if (micro_active(t)) {
        if (chord_last[k].n) {
            n = chord_last[k].n;
            for (i = 0; i < n; i++) nn[i] = chord_last[k].note[i];
        } else n = chord_make(t, 60u, nn, &r, &mask);
        cv_text_c(120, ty_y(16, TY_LB), TY_LB, "SCALE DEGREES", T_MID, T_SURF);
        for (i = 0; i < n; i++) {
            note_name(b, nn[i]);
            cv_text_c(30 + (int32_t)i * 60, ty_y(60, TY_TX), TY_TX, b, i ? c : T_ACCENT, T_SURF);
        }
        return;
    }
    if (chord_last[k].n) {
        r = chord_last[k].root;
        mask = chord_last[k].mask;
        n = chord_last[k].n;
        for (i = 0; i < n; i++)
            nn[i] = chord_last[k].note[i];
    } else {
        n = chord_make(t, (uint32_t)clamp(60 + t->p[P_ROOT] + (t->p[P_CHRD] == CH_AUTO || t->p[P_CHRD] == CH_MELODY ? t->p[P_TRANS] : 0), 0, 127), nn, &r, &mask);
        cap = "ON ROOT";
    }
    if (trk_vmode(t) != V_POLY)
        cap = "ROOT ONLY";                              /* MONO / LEGATO / UNISON */
    if (t->p[P_CHRD] == CH_MELODY) cap = "MELODY";
    if (t->p[P_CHRD] == CH_MELODY) chord_melody_name(b, (uint32_t)r, mask);
    else if (t->p[P_CHRD] == CH_AUTO) chord_auto_name(b, (uint32_t)r, mask);
    else chord_name(b, (uint32_t)r, mask);
    cv_text_on(14, ty_y(18, TY_VL), TY_VL, b, T_TEXT, T_SURF);
    cv_text_r(226, ty_y(18, TY_LB), TY_LB, cap, T_MID, T_SURF);
    lo = nn[0] - nn[0] % 12u;
    cnt = nn[n - 1u] - lo < 24u ? 24u : 36u;
    w = 216u / cnt;
    for (i = 0; i < cnt; i++) {
        uint32_t note = lo + i, on = 0;
        int32_t x = 12 + (int32_t)(i * w);
        for (j = 0; j < n; j++)
            on |= nn[j] == note;
        cv_rrect(x, BLACK[note % 12u] ? 36 : 62, (int32_t)w - 2, 48, w > 6u ? 3 : 2,
                 !on ? T_RAISE : (t->p[P_CHRD] == CH_MELODY ? note == nn[n - 1u] : note % 12u == (uint32_t)r % 12u) ? T_ACCENT : c, T_SURF);
    }
}


static uint32_t steps_hash(const track_t *t)
{
    uint32_t h = 2166136261u, i;
    for (i = 0; i < NSTEP; i++) {
        const step_t *st = &seq_steps(t)[i];
        h = (h ^ (st->note[0] + st->n * 128u + st->time * 1024u + st->flags * 4096u + st->note[1] * 65536u)) *
            16777619u;
        h = (h ^ (st->hit | (uint32_t)st->acc << 8 | (uint32_t)st->note[2] << 16 | (uint32_t)st->note[3] << 24)) * 16777619u;
    }
    return h;
}

static uint32_t str_hash(uint32_t h, const char *s)
{
    while (*s)
        h = (h ^ (uint8_t)*s++) * 16777619u;
    return h;
}


/* WHEEL: the nine drawbars as rounded bars over RAISE slots (the bars of the knob just turned: the accent),
 * their footages under them */
/* The FM charts' parts: an operator box 21 x 17 (rows 23 px apart, columns 24), junction dots, Manhattan routes */
#define FM_BH 17
/* a Manhattan route, 1 px: down from (x0, y0) to the jog row jy, across to x1, down to y1 */
/* a feedback loop on the operator box at (x, y): out of its right side, up, back in on top with an arrow */
/* A return from a lower operator, outside the right edge of the whole stack. */
/* the output bus under the carriers (the leftmost at cl, the rightmost at cr) at y bus, an arrow out on the right */

#ifndef FM6_CHART_HOOK
#define FM6_CHART_HOOK(kind, a, b) ((void)0)   /* ui_render.c (host tests): the chart's parts one by one (its lint) */
#endif
enum { FMH_BOX, FMH_ROUTE, FMH_CAR, FMH_BUS, FMH_FB, FMH_LABEL, FMH_END };
/* FM6's 32 algorithms as charts. FM6_CELL: per operator 1..6 its cell, the column in 24 px steps (bits 0..2) and
 * the row above the output bus (bits 4..5; row 0 = the carriers). The routes, the carriers and the feedback
 * operator are fm6_core.c's FM6_ALG itself (fm6_routes, fm6_car_ops, fm6_fb_op). ui_test.c checks the cells
 * against them (a modulator one row above what it modulates, the carriers on the bottom row and only they, one
 * operator per cell) and the routes against the 32 algorithms written out; ui_render.c lints every chart as drawn
 * (no route through a box or touching another route, no two boxes overlapping, all inside the panel). The cells:
 * a search for the fewest and shortest bends, the operators numbered left to right. */
static const uint8_t FM6_CELL[32][6] = {
    {0x00, 0x10, 0x01, 0x11, 0x21, 0x31}, {0x00, 0x10, 0x02, 0x12, 0x22, 0x32}, {0x00, 0x10, 0x20, 0x01, 0x11, 0x21},
    {0x00, 0x10, 0x20, 0x01, 0x11, 0x21}, {0x00, 0x10, 0x01, 0x11, 0x02, 0x12}, {0x00, 0x10, 0x01, 0x11, 0x02, 0x12},
    {0x00, 0x10, 0x01, 0x11, 0x12, 0x22}, {0x00, 0x10, 0x01, 0x12, 0x11, 0x21}, {0x00, 0x10, 0x02, 0x12, 0x13, 0x23},
    {0x00, 0x10, 0x20, 0x01, 0x11, 0x12}, {0x00, 0x10, 0x20, 0x01, 0x11, 0x12}, {0x00, 0x10, 0x03, 0x12, 0x13, 0x14},
    {0x00, 0x10, 0x02, 0x11, 0x12, 0x13}, {0x00, 0x10, 0x01, 0x11, 0x20, 0x21}, {0x00, 0x10, 0x02, 0x12, 0x21, 0x22},
    {0x01, 0x10, 0x11, 0x21, 0x12, 0x22}, {0x01, 0x12, 0x10, 0x20, 0x11, 0x21}, {0x01, 0x10, 0x12, 0x11, 0x21, 0x31},
    {0x00, 0x10, 0x20, 0x01, 0x02, 0x11}, {0x00, 0x01, 0x10, 0x02, 0x12, 0x13}, {0x00, 0x01, 0x10, 0x02, 0x03, 0x12},
    {0x00, 0x10, 0x01, 0x02, 0x03, 0x12}, {0x00, 0x01, 0x11, 0x02, 0x03, 0x12}, {0x00, 0x01, 0x02, 0x03, 0x04, 0x13},
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x13}, {0x00, 0x01, 0x11, 0x02, 0x12, 0x13}, {0x00, 0x01, 0x11, 0x03, 0x13, 0x14},
    {0x00, 0x10, 0x01, 0x11, 0x21, 0x02}, {0x00, 0x01, 0x02, 0x12, 0x03, 0x13}, {0x00, 0x01, 0x02, 0x12, 0x22, 0x03},
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x14}, {0x00, 0x01, 0x02, 0x03, 0x04, 0x05}};
/* the operator with feedback in algorithm a (0..5: operator 1..6) */
/* MARK I returns OP4 / OP5 in algorithms 4 / 6; MODERN and OPL return OP6 itself. */
/* the carriers of algorithm a: bit k operator k + 1 (fm6_carriers counts the sixth first) */
/* the algorithm FM6 plays on track t (0..31): ALG, or the patch's at PAT */

/* The slots' names live in project.c's metadata (RAM, filled at boot and on each save); the redraw signature over
 * all of them refreshes twice a second */
static uint32_t graph_pname_sig, graph_pmask;

/* play 0: without the playhead of NOTES and the drum grid (ui_pages.c sends it alone) */
static uint32_t graph_sig(int play)
{
    const page_t *pg = cur_page();
    const track_t *t = TSEL;
    uint32_t h = 2166136261u, i;
    if (ui.home)
        return h ^ (ui.frame / 2u);                  /* scope: redraw every other frame */
    h ^= (uint32_t)pg->graph * 131u + TSEL->eng_req + song.sel * 7777u + ui.page * 1291u;
    if (pg->graph == GR_NONE || pg->graph == GR_ARP) h ^= ui.frame / 2u;
    for (i = 0; i < P_COUNT; i++)
        h = (h ^ (uint32_t)t->p[i]) * 16777619u;
    h ^= (uint32_t)TSEL->preset * 7u + (uint32_t)song.g[G_SLOT] * 13u + TSEL->user * 257u + up_gen * 7919u;
    if (pg->scope == SC_TOLD)                        /* (Melodee's values, wave and marks: remote_told.c) */
        h = (h ^ told.gen) * 16777619u + (uint32_t)told.track * 31u;
    if (pg->graph == GR_ROLL && !grid_on()) {
        uint32_t chosen = notes_selected(t);
        notes_follow(t);
        h ^= bulk.on*37u + bulk.anchor*41u + bulk.end*43u;
        h ^= recording_generation * 7919u + chosen * 40503u + ui.note_zoom * 104729u + ui.cursor * 613u + ui.note_slot * 937u + proll.lo * 3001u + (ui.hot_t && (ui.hot_col == 2u || ui.hot_col == 3u) ? 8191u : 0u);
        if (song.playing && (song.rec & (1u << trk_index(t)))) h ^= ui.frame / 2u;
        h = (h ^ steps_hash(t)) * 16777619u;
        h ^= (uint32_t)song.g[G_SWING] * 65537u + pr_held() * 15331u;
        if (play) h ^= (uint32_t)(notes_play_x(t) + 1) * 31u;
    }
    if (pg->graph == GR_CHORD) {                     /* the last chord played */
        h = (h ^ (chord_last[song.sel].root + 131u * chord_last[song.sel].mask)) * 16777619u;
        for (i = 0; i < CHORD_MAX; i++)
            h = (h ^ chord_last[song.sel].note[i]) * 16777619u;
        h ^= (uint32_t)t->engine * 389u;             /* (MONO and kits follow the sounding engine) */
    }
    if (pg->scope == SC_ENGINE && (t->eng_req % NENGINES == ENGI_FM6))
        h ^= (ui.hot_t ? ui.hot_col + 1u : 0u) * 65537u;
    if (pg->graph == GR_STEPS || pg->graph == GR_ROLL) {
        uint32_t ph = song.playing ? t->seq_idx : 0xFFFFu;
        if (pg->graph != GR_STEPS && (ph / 16u != ui.bank || (!play && pg->graph == GR_ROLL)))
            ph = 0xFFFFu;                            /* the roll shows the cursor's bank only */
        h ^= steps_hash(t) + ph * 31u + ui.cursor * 7919u + ui.lane * 104723u + ui.bank * 613u;
    }
    return h;
}
static uint32_t graph_signature(void) { return graph_sig(1); }
/* 4-letter engine tags of the preset list */
static const char *eng_abbr(const char *name)
{
    static const char *const A[][2] = {{"PROPHET", "P5"},
                                       {"PHASE", "PHAS"}, {"CZ-1", "CZ-1"}, {"SID", "SID"},
                                       {"SAMPLE", "SMPL"}, {"VOICE", "VOCL"}, {"TRIO", "TRIO"}, {"WHEEL", "WHEL"},
                                       {"GRAIN", "GRAN"}, {"PHYS", "PHYS"}, {"DRUM", "DRUM"},
                                       {"NOISE", "NOIS"}, {"FM6", "FM6"}, {"SLICE", "SLCE"}};
    uint32_t i;
    for (i = 0; i < sizeof A / sizeof A[0]; i++)
        if (str_eq(name, A[i][0]))
            return A[i][1];
    return name;
}

/* an empty list: a title and a hint, centred */
static void note_line(int32_t y, const char *s, uint16_t fg)   /* centred S; "[K2] ADD PATTERN": a key hint */
{
    uint32_t n;
    int32_t id = kc_tag(s, &n);
    if (id < 0) {
        cv_text_c(120, ty_y(y + 8, TY_LB), TY_LB, s, fg, T_SURF);
        return;
    }
    s += n;
    while (*s == ' ')
        s++;
    cv_text_on(cv_keycap(120 - kh_w((uint32_t)id, s) / 2, y + 8 - KC_PH / 2, (uint32_t)id, T_KEY, T_INK, T_SURF) + KH_GAP,
               ty_y(y + 8, TY_LB), TY_LB, s, fg, T_SURF);
}
static void panel_note(const char *a, const char *b, const char *c)
{
    cv_text_c(120, ty_y(36, ty_fit(TY_TX, a, 220)), ty_fit(TY_TX, a, 220), a, T_TEXT, T_SURF);
    if (b) note_line(60, b, T_MID);
    if (c) note_line(86, c, T_DIM);
}

/* preset browser: the global list (every engine), the current one selected; tag DIM, name TEXT,
 * favourites starred (the accent), the selected row's suggested pattern at its right */

/* a list entry's tag and name, as the browser shows them: "P5" "It's a Proph", "F012" (native), "U07" (user preset) */
static void entry_label(uint32_t e, uint32_t k, char *tag, char *nm)
{
    if (e == USER_NATIVE_P5 || e == USER_NATIVE_FM || e == USER_NATIVE_CZ) {
        uint32_t eng = src_engine(e, k);
        tag[0] = eng == ENGI_PROPHET ? 'P' : eng == ENGI_FM6 ? 'F' : 'Z';
        tag[1] = (char)('0' + (k + 1u) / 100u);
        tag[2] = (char)('0' + (k + 1u) / 10u % 10u);
        tag[3] = (char)('0' + (k + 1u) % 10u);
        tag[4] = 0;
        native_name(eng, k, nm);
    } else if (e == USER_GENERAL) {
        up_slot_label(tag, k);
        up_name(k, nm);
    } else {
        str_cpy(tag, eng_abbr(ENGINES[e % NENGINES]->name), 6);
        str_cpy(nm, eng_preset(ENGINES[e % NENGINES], k)->name, 13);
    }
}
static void p5_short_name(const track_t *t,char *out,uint32_t size)
{
    char full[P5_NAME_LEN+1u];p5_patch_name(full,p5_patch_of((track_t *)t));str_cpy(out,full,size);
}
/* MIXER page: four SURF columns, one under each card: the circled numeral (filled and in the accent:
 * the selected track) with a REC / ARM / MUTE badge (P_MUTE, KNOB 1), the sound's short name (a MUTE badge
 * when armed and muted), the LEVEL knob (dB inside) with the output meter beside it, then the PAN
 * knobs with their values. Knobs: a 270 degree ring, the track RAISE, the value arc THEME (the knob just
 * turned: ACCENT; muted: DIM); PAN from 12 o'clock. Each column is its own canvas with its own signature:
 * while the transport runs only the meters move. */
#define TS_MY 39                                     /* meter slot: column rows 39 .. 70 */
#define TS_MH 32
#define KB_X 4                                       /* LEVEL knob: box 4..37 x 37..70, centre (21, 54) */
#define KB_Y 37
#define KS_Y 86                                      /* PAN knob: boxes 86..105, centres x 15 and 42 */
static struct {
    uint32_t col[NTRK];
    uint8_t meter[NTRK];
} ts;

static int32_t meter_px(int32_t a)                   /* |sample| (Q15) -> px: 60 dB over the slot */
{
    int32_t lg = 0, v;
    if (a < 64)
        return 0;
    while ((a >> lg) > 1)
        lg++;
    v = lg * 8 + (((a << 3) >> lg) & 7);             /* 8 log2(a): 48 (-54 dB) .. 128 (+6 dB) */
    return clamp((v - 48) * (TS_MH - 2) / 80, 0, TS_MH - 2);
}

static uint32_t trk_level(uint32_t c) { return (uint32_t)trk[c].p[P_LEVEL] & 127u; }   /* LEVEL 0..127 */


/* HOME note/chord names: the same recognizer as next, with the 1.0 fonts and palette. */
static const struct {
    uint16_t iv;                                     /* bit i: i semitones over the root */
    char q[8];
} CHORDS[] = {                                       /* simplest first: a chord off its bass takes the first that fits */
    {0x091, ""}, {0x089, "m"}, {0x049, "dim"}, {0x111, "aug"}, {0x0A1, "sus4"}, {0x085, "sus2"},
    {0x491, "7"}, {0x891, "maj7"}, {0x489, "m7"}, {0x449, "m7b5"}, {0x249, "dim7"}, {0x4A1, "7sus4"},
    {0x291, "6"}, {0x289, "m6"}, {0x095, "add9"}, {0x08D, "madd9"}, {0x0B1, "add11"}, {0x0A9, "madd11"},
    {0x889, "mM7"}, {0x511, "7#5"}, {0x451, "7b5"}, {0x911, "maj7#5"}, {0x849, "dimM7"},
    {0x495, "9"}, {0x895, "maj9"}, {0x48D, "m9"}, {0x4A5, "9sus4"}, {0x295, "6/9"}, {0x28D, "m6/9"},
    {0x493, "7b9"}, {0x499, "7#9"}, {0x4D1, "7#11"}, {0x591, "7b13"}, {0x8D1, "maj7#11"},
    /* 11ths and 13ths, also without the 5th or the 9th */
    {0x4B5, "11"}, {0x4AD, "m11"}, {0x4A9, "m11"}, {0x42D, "m11"},
    {0x695, "13"}, {0x691, "13"}, {0x615, "13"}, {0x611, "13"},
    {0x6AD, "m13"}, {0x68D, "m13"}, {0x689, "m13"}, {0x60D, "m13"},
    {0xA95, "maj13"}, {0xA91, "maj13"}, {0xA15, "maj13"},
    /* 7ths and 9ths without the 5th */
    {0x411, "7"}, {0x811, "maj7"}, {0x409, "m7"}, {0x415, "9"}, {0x815, "maj9"}, {0x40D, "m9"},
    {0x413, "7b9"}, {0x419, "7#9"}, {0x851, "maj7#11"},
};
#define NCHORDS (sizeof CHORDS / sizeof CHORDS[0])

/* the chord of pitch classes pcs, *root its root: on the bass when it makes one,
 * else the simplest on another root (shown "/bass") */
static const char *chord_of(uint32_t pcs, uint32_t bass, uint32_t *root)
{
    uint32_t i, k, best = NCHORDS;
    for (i = 0; i < 12u; i++) {
        uint32_t r = (bass + i) % 12u, iv = ((pcs >> r) | (pcs << (12u - r))) & 0xFFFu;
        if (!((pcs >> r) & 1u))
            continue;
        for (k = 0; k < best; k++)
            if (CHORDS[k].iv == iv) {
                best = k;
                *root = r;
                break;
            }
        if (!i && best < NCHORDS)
            break;                                   /* on the bass: no slash */
    }
    return best < NCHORDS ? CHORDS[best].q : 0;
}

/* the lowest of n notes (note[] holds the first 8) that fit in w px of font f, "C4 E4 G4",
 * " .." when some are left out; returns how many are shown */
static uint32_t notes_fit(char *b, const uint8_t *note, uint32_t n, const aafont_t *f, int32_t w)
{
    uint32_t m, i;
    for (m = n < 8u ? n : 8u; m > 1u; m--) {
        b[0] = 0;
        for (i = 0; i < m; i++) {
            if (i)
                str_cpy(b + str_len(b), " ", 2);
            note_name(b + str_len(b), note[i]);
        }
        if (m < n)
            str_cpy(b + str_len(b), " ..", 4);
        if (text_w(f, b) <= w)
            return m;
    }
    note_name(b, note[0]);
    return 1;
}

/* oscilloscope of the output, triggered on a rising zero crossing: a RAISE centre line, the trace 2 px */
static int16_t scope_snap[SCOPE_N];          /* refilled by each HOME/Stage scope draw */
static void graph_scope(uint16_t c, int32_t top, int32_t h)
{
    int16_t *snap = scope_snap;
    uint32_t w = scope_w, i, trig = 0;
    int32_t cy = top + h / 2, py = cy, x, peak = 1500;
    for (i = 0; i < SCOPE_N; i++) {
        if(!cv_top)snap[i] = scope_buf[(w + i) & (SCOPE_N - 1u)];
        if (snap[i] > peak)
            peak = snap[i];
        else if (-snap[i] > peak)
            peak = -snap[i];
    }
    for (i = 1; i < SCOPE_N - 240u; i++)
        if (snap[i - 1] < 0 && snap[i] >= 0) {
            trig = i;
            break;
        }
    cv_rect(PANEL_X0, cy, PANEL_W, 1, T_RAISE);
    for (x = 0; x < PANEL_W; x++) {
        int32_t y = cy - snap[trig + (uint32_t)x] * (h / 2 - 10) / peak;   /* auto-scaled */
        if (x)
            cv_line_t(PANEL_X0 - 1 + x, py, PANEL_X0 + x, y, c, 2);
        py = y;
    }
}

/* A told sample's or clip's wave (remote_told.c WAVE, MARKS): its peaks in the track's colour, dim outside START .. END;
 * its marks as lines (START, END the theme's; the loop's the accent; a cut, a warp marker thin; a fade a slope; the gain
 * points a line through them; where it plays the text's), the selected one bright and thicker */
static void graph_wave(uint16_t c)
{
    int32_t top = 8, bot = H_GRAPH - 8, mid = (top + bot) / 2, x0 = 8, w = (int32_t)TOLD_WAVE_W, i, start = 0, end = w;
    int32_t gx = -1, gy = 0;
    uint16_t dim = ux_mix(T_SURF, c, 35);
    for (i = 0; i < (int32_t)told.nmarks; i++) {
        uint32_t kind = told.mark[i].kind & ~TM_SELECTED;
        int32_t x = clamp(told.mark[i].pos, 0, 8191) * w / 8192;
        if (kind == TM_START) start = x;
        if (kind == TM_END) end = x;
    }
    cv_rect(x0, mid, w, 1, T_RAISE);
    for (i = 0; i < w; i++) {                         /* the peaks */
        int32_t lo = told.wave[i][0], hi = told.wave[i][1], y0, y1;
        if (lo == 0 && hi == 0)
            continue;                                 /* (not told) */
        y0 = mid - (hi - 64) * (bot - top) / 128;
        y1 = mid - (lo - 64) * (bot - top) / 128;
        if (y1 < y0) { int32_t s = y0; y0 = y1; y1 = s; }
        cv_rect(x0 + i, y0, 1, y1 - y0 + 1, i >= start && i <= end ? c : dim);
    }
    for (i = 0; i < (int32_t)told.nmarks; i++) {      /* the marks */
        uint32_t kind = told.mark[i].kind & ~TM_SELECTED, sel = (told.mark[i].kind & TM_SELECTED) != 0u;
        int32_t x = x0 + clamp(told.mark[i].pos, 0, 8191) * w / 8192, t = sel ? 3 : 1, y;
        uint16_t mc = kind == TM_START || kind == TM_END ? T_THEME : kind == TM_LOOP_START || kind == TM_LOOP_END ? T_ACCENT :
                      kind == TM_PLAYING ? T_TEXT : kind == TM_WARP ? T_KNOB(1) : kind == TM_CUT ? T_KNOB(2) : T_KNOB(3);
        if (sel)
            mc = T_TEXT;
        switch (kind) {
        case TM_GAIN:                                 /* (a point, the line from the last one) */
            y = mid - clamp(told.mark[i].value, -600, 120) * (bot - top) / 2 / 720;
            if (gx >= 0)
                cv_line_t(gx, gy, x, y, mc, 2);
            cv_disc(x, y, sel ? 7 : 5, mc, 0);
            gx = x;
            gy = y;
            break;
        case TM_FADE_IN:
            cv_line_t(x0 + start, bot, x, top, mc, t);
            break;
        case TM_FADE_OUT:
            cv_line_t(x, top, x0 + end, bot, mc, t);
            break;
        default:
            cv_rect(x - t / 2, top - 4, t, bot - top + 8, mc);
            if (kind == TM_START || kind == TM_END || kind == TM_LOOP_START || kind == TM_LOOP_END)
                cv_rect(kind == TM_START || kind == TM_LOOP_START ? x : x - 6, top - 4, 6, 3, mc);
            break;
        }
    }
}

/* Each arrangement row selects one bank per track. graph_y, graph_h: the panel's place (ui_pages.c: under its rings) */
static void draw_graph(void)
{
    const page_t *pg = cur_page();
    const track_t *t = TSEL;
    uint16_t c = ACC;
    uint32_t sig;
    sig = graph_signature();
    if (!ui.force && sig == ui.graph_sig)
        return;
    ui.graph_sig = sig;
    for (uint32_t band = 0; band < (uint32_t)((uint32_t)graph_h); band += CV_MAX / (240)) {
        cv_begin_band(240,(uint32_t)graph_h,T_BG,band);
        cv_rrect(3, 0, 234, graph_h, 5, T_SURF, T_BG);   /* the panel */
        cv_bg = T_SURF;                                  /* (text drawn with cv_text lands on it) */
        cv_oy = graph_oy;                                /* graphs on a 100 px scale */
        if (ui.home) {                                   /* (Stage draws its own panel: ui_stage.c) */
            cv_oy = 0;
            graph_scope(c, 0, H_GRAPH);
        } else {
            switch (pg->graph) {
            case GR_WAVE:                                    /* a told sample or clip (remote_told.c) */
                cv_oy = 0;
                graph_wave(c);
                break;
            case GR_LFO:
                graph_lfo(t, c);
                break;
            case GR_STEPS:
                graph_steps(t, c);
                break;
            case GR_ROLL:
                cv_oy = 0;
                if (grid_on()) graph_grid(t, c);
                else { proll.play = notes_play_x(t); graph_recorded_notes(t, c); }
                break;
            case GR_SCALE:
                if (scale_settings_page(pg)) {
                    cv_oy = 0;
                    const char *st = SCALE_TITLE[clamp(t->p[P_SCALE], 0, SCALE_TOTAL - 1u)];
                    cv_free_text(12, ty_y(14, ty_fit(TY_TX, st, 216)), ty_fit(TY_TX, st, 216), st, T_TEXT, T_SURF, 216);
                    cv_oy = 24;
                }
                graph_scale(t, c);
                break;
            case GR_CHORD:
                cv_oy = 0;
                graph_chord(t, c);
                break;
            default:
                cv_oy = 0;
                graph_scope(c, 0, H_GRAPH);
                break;
            }
        }
        cv_oy = 0;
        cv_blit_band(0, (uint32_t)graph_y);
    }
}
